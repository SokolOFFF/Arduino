//******************************************************************
//
// Name:DigitalTube liararies v0.9b for Grove - 4-Digit Display v1.0
// Author:Frankie.Chu at Seeed Studio.
// Date:April 9,2012
// Version:0.9b
// Software platform:Arduino-1.0
// Hardware platform:Arduino UNO/Seeeduino/Arduino Mega +
//                   Grove - 4-Digit Display
// Demo code:
//   ClockDisplay: Display a clock like 12:00.
//   NumberFlow: Numbers from 0 to 9 flow from right to left.
//   Stopwatch: A stopwatch that can be controled by the serial
//		monitor.
//
//*******************************************************************